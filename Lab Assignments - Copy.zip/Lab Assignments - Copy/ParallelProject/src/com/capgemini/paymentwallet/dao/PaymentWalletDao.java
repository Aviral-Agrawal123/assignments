package com.capgemini.paymentwallet.dao;


import java.util.HashMap;

import com.capgemini.paymentwallet.bean.PaymentWalletBean;

public class PaymentWalletDao implements PaymentWalletDaoInterface {
	
	HashMap map = new HashMap();

	public void accountCreation(PaymentWalletBean bean) {
		map.put(bean.getAccountNumber(), bean);
	}
}
