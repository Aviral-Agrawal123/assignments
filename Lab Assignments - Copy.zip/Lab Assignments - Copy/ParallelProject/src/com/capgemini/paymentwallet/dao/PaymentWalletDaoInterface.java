package com.capgemini.paymentwallet.dao;

import com.capgemini.paymentwallet.bean.PaymentWalletBean;

public interface PaymentWalletDaoInterface {

	void accountCreation(PaymentWalletBean bean);
}
