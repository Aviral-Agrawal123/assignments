package com.capgemini.paymentwallet.service;

import com.capgemini.paymentwallet.bean.PaymentWalletBean;
import com.capgemini.paymentwallet.dao.PaymentWalletDao;

public class PaymentWalletService implements PaymentWalletServiceInterface{
	
	PaymentWalletDao obj = new PaymentWalletDao();
	long accNo;

	public long createAccount(PaymentWalletBean bean) {
		
		if(nameCheck(bean.getName()) && emailCheck(bean.getEmailId()) && numberCheck(bean.getMobileNumber())) {
			accNo = ((bean.getMobileNumber())-123455)*7;
			bean.setAccountNumber(accNo);
			obj.accountCreation(bean);
		}
		return accNo;
	}
	
	public long showBalance(long accountNumber) {
		return accountNumber;
		
	}
	public void deposit(double depositAmount, long accountNumber) {
		
	}
	public void withdraw(double withdrawAmount, long accountNumber) {
		
	}
	public void fundTransfer(double amount, long sourceAccNumber, long destinationAccNumber) {
		
	}
	public void printTransaction(long accountNumber) {
		
	}
	
	boolean nameCheck(String name) {
		//boolean result = name.matches("[a-zA-Z] {3,}");
		return true;	
	}
	
	boolean emailCheck(String emailId) {
		//boolean result = emailId.matches(");
		return true;
	}
	
	boolean numberCheck(long mobile) {
		//boolean result = (String.valueOf(mobile).length())==10;
		return true;
	}
}
