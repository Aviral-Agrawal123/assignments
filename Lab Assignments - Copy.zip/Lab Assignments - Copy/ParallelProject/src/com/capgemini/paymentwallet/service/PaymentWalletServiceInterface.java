package com.capgemini.paymentwallet.service;

import com.capgemini.paymentwallet.bean.PaymentWalletBean;

public interface PaymentWalletServiceInterface {

	long createAccount(PaymentWalletBean bean);
	long showBalance(long accountNumber);
	void deposit(double depositAmount, long accountNumber);
	void withdraw(double withdrawAmount, long accountNumber);
	void fundTransfer(double amount, long sourceAccNumber, long destinationAccNumber);
	void printTransaction(long accountNumber);
}
