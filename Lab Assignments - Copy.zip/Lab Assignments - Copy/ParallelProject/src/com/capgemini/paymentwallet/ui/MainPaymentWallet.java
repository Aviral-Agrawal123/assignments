package com.capgemini.paymentwallet.ui;

import java.util.Scanner;

import com.capgemini.paymentwallet.bean.PaymentWalletBean;
import com.capgemini.paymentwallet.service.PaymentWalletService;

public class MainPaymentWallet {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to our application");
		System.out.println("Please select following options");
		System.out.println("Press 1. Create Account");
		System.out.println("Press 2. Show Balance");
		System.out.println("Press 3. Deposit");
		System.out.println("Press 4. Withdraw");
		System.out.println("Press 5. Fund Transfer");
		System.out.println("Press 6. Print Transaction");
		int choice = sc.nextInt();
		sc.nextLine();
		char repeatChoice='y';
		long accountNumber;
		PaymentWalletService obj = new PaymentWalletService();
		PaymentWalletBean bean;
		do {
			switch(choice) {
				case 1:
					System.out.println("Enter your Name: ");
					String name = sc.nextLine();
					
					System.out.println("Enter your Email-Id: ");
					String emailId = sc.nextLine();
					System.out.println("Enter your Mobile Number: ");
					long mobileNumber = sc.nextLong();
					bean = new PaymentWalletBean();
					bean.setName(name);
					bean.setEmailId(emailId);
					bean.setMobileNumber(mobileNumber);
					accountNumber = obj.createAccount(bean);
					System.out.println("Your Account created Successfully");
					System.out.println("Your Account Number is: "+accountNumber);
					break;
				
				case 2:
					System.out.println("Enter your Account Number");
					accountNumber = sc.nextLong();
					long balance = obj.showBalance(accountNumber);
					System.out.println("Your current balance is : "+balance);
					break;
				
				case 3:
					System.out.println("Enter your Account Number");
					accountNumber = sc.nextLong();
					System.out.println("Enter the amount you want to deposit :");
					double depositAmount = sc.nextDouble();
					obj.deposit(depositAmount, accountNumber);
					break;
					
				case 4:
					System.out.println("Enter your Account Number");
					accountNumber = sc.nextLong();
					System.out.println("Enter the amount you want to withdraw :");
					double withdrawAmount = sc.nextDouble();
					obj.withdraw(withdrawAmount, accountNumber);
					break;
					
				case 5:
					System.out.println("Enter the amount you want to transfer :");
					double amount = sc.nextDouble();
					System.out.println("Enter Source Account Number: ");
					long sourceAccNumber = sc.nextLong();
					System.out.println("Enter Destination Account Number: ");
					long destinationAccNumber = sc.nextLong();
					obj.fundTransfer(amount, sourceAccNumber, destinationAccNumber);
					break;
					
				case 6:
					System.out.println("Enter your Account Number");
					accountNumber = sc.nextLong();
					obj.printTransaction(accountNumber);
					break;
					
				default:
					System.out.println("Please make a valid choice");
				}
			System.out.println("Do you want to continue. Press y or n");
			repeatChoice = sc.next().charAt(0);
		}while(repeatChoice=='y' || repeatChoice=='Y');
		sc.close();
		System.out.println("Thank you for using our service. ");
	}
}
