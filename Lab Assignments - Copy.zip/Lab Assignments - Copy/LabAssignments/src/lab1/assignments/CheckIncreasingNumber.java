package lab1.assignments;

import java.util.Scanner;

public class CheckIncreasingNumber {

	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of n");
		int number=sc.nextInt();
		CheckIncreasingNumber obj = new CheckIncreasingNumber();
		boolean result = obj.checkNumber(number);
		if(result==true)
			System.out.println(number+" is an inceasing number");
		else
			System.out.println(number+" is not an increasing number");
		sc.close();
	}
	//method to check if the number is increasing number or not
	public boolean checkNumber(int n){
		int counter=0;
		String string = String.valueOf(n);
		int length=string.length();
		for(int i=0 ; i<length-1 ;i++){
			if(string.charAt(i)>string.charAt(i+1))
				counter++;
		}
		if(counter==0)
			return true;
		else
			return false;
	}
}
