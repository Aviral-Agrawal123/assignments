package lab10.assignments;

import java.util.Scanner;
import java.util.function.UnaryOperator;

public class StringFormat {

	public static void main(String[] args) 
	{
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the string you wish to enter ");
	String str=sc.nextLine();
	//String s=a.apply(str);
	System.out.println(s);
	}

}
