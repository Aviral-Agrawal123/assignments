package lab6.assignments;

import java.io.File;

public class DisplayInformationOfFile {

	public static void main(String[] args){
		System.out.println("Enter the name of the file:");
		File f1 = new File("C:\\Users\\shikhyad\\Lab Assignments\\LabAssignments\\src\\lab6\\assignments\\abc.txt");
		
		//check whether the given file exists or not
		if(f1.exists()) {
			System.out.println("The file " +f1.getName()+ " exists");
			
			//check if the given file is readable or not
			if(f1.canRead())
				System.out.println("The file " +f1.getName()+" is readable");
			else
				System.out.println("The file " +f1.getName() +" is not readable");
			
			//check if you can write 
			if(f1.canWrite())
				System.out.println("The file " +f1.getName()+ " is writeable");
			else
				System.out.println("The file " +f1.getName()+ " is not writeable");
		}
		else
			System.out.println("The file " +f1.getName()+ " does not exist");
		System.out.println("The file type is: " +f1.getName().substring(f1.getName().indexOf('.')+1));
		System.out.println("The Length of the file:" +f1.length());
	}
}
