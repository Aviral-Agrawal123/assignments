package lab8.assignments;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread {

	FileInputStream fromFile;
	FileOutputStream toFile;
	public void init(String arg1,String arg2)throws FileNotFoundException{
		try{
			fromFile=new FileInputStream(arg1);
			toFile=new FileOutputStream(arg2);
		}catch(FileNotFoundException fe){
			System.out.println("Exception :"+fe); 
			throw fe;
		}
	}
	
	
public void copyContents()throws IOException, InterruptedException{
	try{
		int i=fromFile.read();
		int chacount=0;
		
		while(i!=-1){
			char ch1=(char)i;
			System.out.println(ch1);
			chacount++;
			if(chacount==10)
			{
				System.out.println("\n10 Characters Copied.");
				chacount=0;
				Thread.sleep(5000);
			}
			toFile.write(i);
			i=fromFile.read();
			
		}}catch(IOException ioe)
		{
			System.out.println("Exception :"+ioe);
			throw ioe;
			
		}finally{
			if(fromFile!=null)
			{
				fromFile.close();
			}
			if(toFile!=null)
			{
				toFile.close();
			}
		}

	
}
public static void main(String[] args) throws InterruptedException{
	CopyDataThread  c1=new CopyDataThread();
	try{
		c1.init("source.txt","target.txt");
		c1.copyContents();
	}
	catch(IOException e){
		System.out.println("caught in main"+e);
		
	}
}

}
